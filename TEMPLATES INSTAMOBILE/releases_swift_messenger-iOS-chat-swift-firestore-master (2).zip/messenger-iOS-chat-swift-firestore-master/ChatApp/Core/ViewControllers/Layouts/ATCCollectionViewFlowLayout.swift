//
//  ATCCollectionViewFlowLayout.swift
//  RestaurantApp
//
//  Created by Florian Marcu on 4/25/18.
//  Copyright © 2018 iOS App Templates. All rights reserved.
//

import UIKit

public class ATCCollectionViewFlowLayout: UICollectionViewFlowLayout {
    weak var delegate: ATCLiquidLayoutDelegate?
}
