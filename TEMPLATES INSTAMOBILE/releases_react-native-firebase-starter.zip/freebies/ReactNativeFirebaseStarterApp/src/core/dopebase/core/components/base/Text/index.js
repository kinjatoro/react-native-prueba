import Text from './Text'
export { Text }
