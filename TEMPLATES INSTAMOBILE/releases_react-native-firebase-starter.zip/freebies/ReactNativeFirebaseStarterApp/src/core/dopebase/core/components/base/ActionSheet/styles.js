import { StyleSheet } from 'react-native'

const styles = (theme, appearance) => {
  return StyleSheet.create({})
}

export default styles
