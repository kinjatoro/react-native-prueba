<p align="center">
	<a href="https://instamobile.io/app-templates/react-native-login-screen-template/"><img src="https://www.instamobile.io/wp-content/uploads/2018/04/react-native-login-screen-template-cover.png" alt = "React Native Login Screen"/></a>
</p>

## React Native Login Screen for Android &amp; iOS

You can preview this app on <a href="https://expo.io/@floryan2oo7">Expo</a>, on both iOS and Android.

## About

This is a simple react native login screen It has support for <b>signing in with
Facebook</b>, as well as the classic email & password form.

The template uses Facebook Login framework, provided by Expo.

## Documentation

If you want even more details on the project, please visit <a href="https://instamobile.io/">Instamobile</a> and <a href="https://iosapptemplates.com">iOS App Templates</a>.
