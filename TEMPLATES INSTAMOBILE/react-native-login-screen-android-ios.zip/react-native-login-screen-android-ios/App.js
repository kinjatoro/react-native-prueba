import React from "react";
import LoginScreen from "./src/login/login.js";

export default function App() {
  return <LoginScreen />;
}
