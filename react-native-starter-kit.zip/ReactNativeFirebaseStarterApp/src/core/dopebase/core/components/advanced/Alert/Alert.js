import { Alert as RNAlert } from 'react-native'
export const Alert = RNAlert
